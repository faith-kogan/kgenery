export default from "../calcApp/SwitchApp";
