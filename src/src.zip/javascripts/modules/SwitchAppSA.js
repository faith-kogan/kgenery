export default from "../calcApp/SwitchAppSA";
