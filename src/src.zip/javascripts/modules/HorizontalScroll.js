import dragScroll from "dragscroll";

export default class HorizontalScroll {
	constructor(el) {
		this.el = el
	}
}