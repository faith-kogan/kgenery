import React, { Fragment } from "react";
import PropTypes from "prop-types";

// Data
import * as calcData from "../data/calcData";
import Button from "../components/Button";
import KoganBrandedButton from "../components/kogan/KoganBrandedButton";
import Tooltip from "../components/Tooltip";

const SwitchAppResidentialInfo = props => {
  const {
    rates,
    fuelType,
    distributor,
    state,
    terms,
    handleTerms,
    showSolar,
    onClickJoinNow,
  } = props;

  let averageSpend, percentageDiff, percentageDiffLessMore;

  if (showSolar) {
    ({
      averageSpendSolar: averageSpend,
      percentageDiffSolar: percentageDiff,
      percentageDiffLessMoreSolar: percentageDiffLessMore
    } = rates);
  }
  else {
    ({
      averageSpend, percentageDiff, percentageDiffLessMore
    } = rates);
  }

  return (
    <div className="s-cms-content ">
      {fuelType === "electricity" ? (
        <Fragment>
          <div className="kogan-estimate">
            <div className="u-font-p1"><strong>Pay an estimated</strong></div>
            <div className="u-font-h3">
              {averageSpend} per year
            </div>
            <div className="u-font-p2 secondary">All prices quoted include GST</div>
          </div>
          <hr />
          <div className="kogan-rates">
            <div className="u-font-h3"><strong>{percentageDiff}</strong></div>
            <div className="ref-price u-font-p4">
              {percentageDiffLessMore} the{' '}
              {state === calcData.vic ? (
                        <Fragment>
                          Victorian Default Offer{' '}
                          <Tooltip
                            name="distributorNameTip"
                            content="The Victorian Default Offer is a set of rates set by the Essential Services Commission (ESC) which we are required to compare our Market Offer against."
                          />
                        </Fragment>
                      ) : (
                        <Fragment>
                          reference price{' '}
                          <Tooltip
                            name="distributorNameTip"
                            content="The Federal government requires all energy retailers in NSW, QLD and SA to compare their Market Offer against the Default Market Offer. The Default Market Offer is a maximum annual price retailers can charge a Standing Offer customer based on an average customer’s usage, tariff and distribution area and is referred to as the reference price."
                          />
                        </Fragment>
                      )}
            </div>
          </div>
          <p>
            
            These prices are based on an average customer who uses <strong>{rates.energyConsumed}</strong> per year on a <strong>{rates.tariffName}</strong> tariff in the <strong>{distributor}</strong> network. Your actual bill will vary based on your usage and tariff. If you have a different tariff type, such as a Time of Use Tariff,
            view your {state === calcData.vic ? (
                <Fragment>
                  <a href="/vefs/">
                    <strong>Energy Fact Sheet</strong>
                  </a>.
                </Fragment>
              ) : (
                <Fragment>
                  <a href="/basic-plan-information/">
                    <strong>Basic Plan Information</strong>
                  </a>.
                </Fragment>
              )}
          </p>
          <hr />
          {
            showSolar &&
            <Fragment>
              <div className="u-font-h5">
                Solar feed-in tariff - <span className="font-normal-weight">{rates.solarFeed}</span>
              </div>
              <hr />
            </Fragment>
          }
          <div className="u-font-h4">
            <ul className="kogan-benefits">
              <li>
                Flexible billing
              </li>
              <li>
                Great customer service
              </li>
              <li>
                Easy to use app
              </li>
            </ul>
          </div>
          <hr />
          <KoganBrandedButton
            className="btn-centered btn-bold kogan-join-now"
            iconName="kgnArrowRight"
            labelText="JOIN NOW"
            onClick={onClickJoinNow}
          />
        </Fragment>
      ) : (
        <Fragment>
        <div className="kogan-estimate">
            <div className="u-font-p1"><strong>Pay an estimated</strong></div>
            <div className="u-font-h3">
              {rates.annualSpend} per year
            </div>
            <div className="u-font-p2 secondary">All prices quoted include GST</div>
          </div>
          <p>
            These prices are based on an average customer who uses <strong>{rates.energyConsumed}</strong> per year on
            a <strong>Single Rate tariff</strong> in the <strong>{distributor}</strong> network.
            Your actual bill will vary based on your usage. View your <strong><a href="/vefs/" target="_blank" rel="nofollow noopener">Energy Fact Sheet</a></strong>.
          </p>


          <hr />
          <div className="u-font-h4">
            <ul className="kogan-benefits">
              <li>
                Flexible billing
              </li>
              <li>
                Great customer service
              </li>
              <li>
                Easy to use app
              </li>
            </ul>
          </div>
          <hr />
          <KoganBrandedButton
            className="btn-centered btn-bold kogan-join-now"
            iconName="kgnArrowRight"
            labelText="JOIN NOW"
            onClick={onClickJoinNow}
          />
        </Fragment>
      )}
    </div>
  );
};

SwitchAppResidentialInfo.propTypes = {
  rates: PropTypes.shape({}).isRequired,
  fuelType: PropTypes.string.isRequired,
  distributor: PropTypes.string.isRequired,
  state: PropTypes.string.isRequired,
  showSolar: PropTypes.bool,
  onClickJoinNow: PropTypes.func.isRequired,
};

SwitchAppResidentialInfo.defaultProps = {
  showSolar: false,
};

export default SwitchAppResidentialInfo;
