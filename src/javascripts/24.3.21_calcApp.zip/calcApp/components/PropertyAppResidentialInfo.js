import React, { Fragment } from "react";
import PropTypes from "prop-types";

// Data
import * as calcData from "../data/calcData";
import Button from "../components/Button";
import Tooltip from "../components/Tooltip";

const tooltipVDO = `
The Victorian Default Offer is a set of rates 
set by the Essential Services Commission (ESC) 
which we are required to compare our Market Offer against.`;

const tooltipBPID = `
All energy retailers 
in NSW, QLD and SA to compare their Market Offer 
against the Default Market Offer. 
The Default Market Offer is a maximum annual price 
retailers can charge a Standing Offer customer 
based on an average customer’s usage, tariff and 
distribution area and is referred to as the reference price.`;


const PropertyAppResidentialInfo = props => {
  const {
    rates,
    fuelType,
    distributor,
    state,
    onClickJoinNow,
  } = props;

  return (

<div className="c-pre-signup">

{fuelType === "electricity" ? (
// ELECTRICITY TAB CONTENT
<Fragment>
{/* SECTION: ESTIMATED */}
  <section className="o-layout--center c-cro__section-estimated">
    <p className="u-margin-bottom-zero">&nbsp;</p>
    <p className="u-margin-bottom-base c-cro__section-estimated-note stagger-element-estimate">Based on your postcode, you can signup to our offer:</p>
    
    <div className="o-flex-layout o-flex-layout--center-all u-margin-bottom-base stagger-element-estimate">
    
    {state === calcData.vic ? (
      <p className="u-font-h4 u-margin-bottom-zero">Powershop 100% Carbon Neutral</p>
      ): (
      <Fragment>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 70 70">
        <path fill="#fa0e6a" stroke="#fa0e6a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" d="M38.3 1.667l-33.3 40h30l-3.3 26.7 33.3-40H35z"/>
      </svg>
      <p className="u-font-h4 u-margin-bottom-zero">Powershop Shopper</p>
      </Fragment>
    )}
      
    </div>
    
    <p className="u-margin-bottom-zero stagger-element-estimate">Where you will pay an estimated</p>
    <p className="c-cro__section-estimated-amount stagger-element-estimate" data-autopay-amount={rates.annualPriceAutopay} data-autopay-more={rates.autopayMore}>
      <span className="dollar-style">$</span>
      <span id="autopay_amount">{new Intl.NumberFormat().format(rates.annualPriceAutopay)}</span>
    </p>
    <p className="u-font-h5 u-margin-bottom-tiny">per year</p>
    <p className="c-cro__section-estimated-gst stagger-element-estimate">(incl. GST)</p>

    {rates.compareEqualTo ? (
    <p className="c-cro__section-estimated-percent stagger-element-estimate">That's {rates.compareAutopay}&nbsp;
    {state === calcData.vic ? (
      <Tooltip name="the&nbsp;Victorian&nbsp;Default&nbsp;Offer" content={tooltipVDO}/>
    ) : (
      <Tooltip name="the&nbsp;reference&nbsp;price" content={tooltipBPID}/>
    )}
    </p>
    ) : (
    <p className="c-cro__section-estimated-percent stagger-element-estimate">That's <strong>{rates.percentOffAutopay}%</strong> {rates.compareAutopay}&nbsp;
    {state === calcData.vic ? (
      <Fragment>
        <Tooltip name="the&nbsp;Victorian&nbsp;Default&nbsp;Offer" content={tooltipVDO}/>
      </Fragment>
    ) : (
      <Tooltip name="the&nbsp;reference&nbsp;price" content={tooltipBPID}/>
    )}
    </p>
    )}
    
    <div className="c-box c-box--trigger stagger-element-estimate">
      <p className="u-margin-bottom-zero">Estimated cost and comparison <strong>for a residential customer</strong> using {rates.energyConsumed} on a Single rate tariff in the {distributor} network.</p>
    </div>
    
  </section>

<div className="timeline-bottom u-relative">
  <hr />
{/* Disclaimer info */}
<p id="section_details">Ongoing contract, until you or we end it. The estimate above is based on an average residential customer. Your actual bills will vary depending on your usage, rates and any price changes in the future.&nbsp;
The estimate does not include concessions or other rebates, distributor service order costs, fees or, for electricity, solar feed in tariffs that may apply to you.</p>

{state === calcData.vic ? (
    <Fragment>
    <p>View your <a id="cro_new_vefs" target="_blank" href="/vefs/">Energy Fact Sheet</a>.</p>
    <p>We offset all carbon emissions associated with your energy usage at no additional fee.</p>
    <p>You may also be able to access our standing offer, including the Victorian Default Offer. For more information on our standing offer and Victorian Default offer, please call <a href="tel:1800-462-668" target="_blank">1800 462 668</a>.</p>
    <p>We may have other generally available offers that may be more suitable for you. Please <a href="tel:1800-462-668" target="_blank">call us</a> if you want to discuss.</p>
    </Fragment>
  ) : (
    <Fragment>
    <p>View your <a id="cro_new_bpids" target="_blank" href="/basic-plan-information/">Basic Plan Information</a>.</p>
    <p>We offset all carbon emissions associated with your energy usage at no additional fee.</p>
    <p>You may also be able to access our standing offer. For more information on our standing offer, please call <a href="tel:1800-462-668" target="_blank">1800 462 668</a>.</p>      
    </Fragment>
  )}

  </div>
</Fragment>

// end fuel type electricity

) : (

// GAS TAB CONTENT
<Fragment>
<section className="o-layout--center c-cro__section-estimated">
  <p className="u-margin-bottom-zero">&nbsp;</p>
  <p className="u-margin-bottom-base c-cro__section-estimated-note stagger-element-estimate">Based on your postcode, you can signup to our offer:</p>    
  <div className="o-flex-layout o-flex-layout--center-all u-margin-bottom-base stagger-element-estimate">
    <p className="u-font-h4 u-margin-bottom-zero">Powershop 100% Carbon Neutral</p>
  </div>

  <p className="u-margin-bottom-zero stagger-element-estimate">Where you will pay an estimated</p>
  <p className="c-cro__section-estimated-amount" data-autopay-amount={rates.annualSpend}>
    <span className="dollar-style">$</span>
    <span id="autopay_amount">{rates.annualSpend}</span>
  </p>
  <p className="u-font-h5 u-margin-bottom-tiny">per year</p>
  <p className="c-cro__section-estimated-gst">(incl. GST)</p>
  
  <div className="c-box">
    <p className="u-margin-bottom-tiny">
      These prices are based on an average customer who uses&nbsp;
      <strong>{rates.energyConsumed}</strong> per year on a&nbsp;
      <strong>Single Rate tariff</strong> in the&nbsp;
      <strong>{distributor}&nbsp;</strong>network. Your actual bill will vary based&nbsp;
      on your usage.
    </p>
    <p className="u-margin-bottom-zero">View your&nbsp;
      {state === calcData.vic ? (
      <Fragment>
      <a id="cro_new_vefs" target="_blank" href="/vefs/">Energy Fact Sheet</a>.
      </Fragment>
      ) : (
      <Fragment>
        <a id="cro_new_bpids" target="_blank" href="/basic-plan-information/">Basic Plan Information</a>.
      </Fragment>
      )}
    </p>
  </div>
</section>
</Fragment>
)}
</div>
)};



PropertyAppResidentialInfo.propTypes = {
  rates: PropTypes.shape({}).isRequired,
  fuelType: PropTypes.string.isRequired,
  distributor: PropTypes.string.isRequired,
  state: PropTypes.string.isRequired,
  onClickJoinNow: PropTypes.func.isRequired,
};

export default PropertyAppResidentialInfo;
