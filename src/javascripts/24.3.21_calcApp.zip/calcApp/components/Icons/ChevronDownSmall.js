import React from "react";

const ChevronDownSmall = () => (
  <svg
    width="500px"
    height="285.7px"
    viewBox="0 0 500 285.7"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M250,246.7c-5.9,0-11.8-2.3-16.3-6.8L96,102.2c-9-9-9-23.5,0-32.5s23.5-9,32.5,0L250,191.3L371.5,69.8c9-9,23.5-9,32.5,0
	c8.9,9,9,23.5,0,32.5L266.3,240C261.8,244.4,255.8,246.7,250,246.7z"
    />
  </svg>
);

export default ChevronDownSmall;
